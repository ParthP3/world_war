#include <iostream>
#include <string>
#include "hashing.cpp"

using namespace std;


int main() {
    string s;
    cin >> s;
    cout << hash_string(s) << endl;
}
