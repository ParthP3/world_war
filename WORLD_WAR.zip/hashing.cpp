#include "hashing.hpp"

int hash_string(string s) {
    int p = 41;
    int sum = 0;
    for (int i = 0; i < s.length(); i++) {
    }
    return sum;
}
